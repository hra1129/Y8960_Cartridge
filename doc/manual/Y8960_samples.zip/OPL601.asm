;-----------------------------------------------------------------------
;	OPL601.asm - OPL2 の FM 発音 (Y8960)
;	Ch.1 に簡単な FM 音色を設定し、A4 (440Hz) を鳴らすサンプル。
;	4000h 配置の ROM 形式。zma でアセンブルする。
;-----------------------------------------------------------------------
		org		4000h
		db		"AB"
		dw		start

;	OPL2 レジスタ書き込み (A = レジスタ番号, E = データ)
opl2w:
		out		[0c0h], a
		ld		a, e
		out		[0c1h], a
		ret

;	約 1 秒待つ
wait1s:
		ld		bc, 0
w1:		dec		bc
		ld		a, b
		or		c
		jr		nz, w1
		ret

start:
		; Enabler2 (MMIO 7FFFh) の OPL2 ビットを 1 にして OPL2 を有効化
		ld		a, 01h
		ld		[7fffh], a

		; レジスタ 01h の b5 を 1 にして波形選択を有効化
		ld		a, 01h
		ld		e, 20h
		call	opl2w

		;--- Ch.1 モジュレータ (スロット 00h) ---
		ld		a, 20h			; MULTI = 1
		ld		e, 01h
		call	opl2w
		ld		a, 40h			; TL = 24
		ld		e, 18h
		call	opl2w
		ld		a, 60h			; AR = 15, DR = 6
		ld		e, 0f6h
		call	opl2w
		ld		a, 80h			; SL = 6, RR = 6
		ld		e, 66h
		call	opl2w

		;--- Ch.1 キャリア (スロット 03h) ---
		ld		a, 23h			; MULTI = 1
		ld		e, 01h
		call	opl2w
		ld		a, 43h			; TL = 0 (最大)
		ld		e, 00h
		call	opl2w
		ld		a, 63h			; AR = 15, DR = 4
		ld		e, 0f4h
		call	opl2w
		ld		a, 83h			; SL = 4, RR = 6
		ld		e, 46h
		call	opl2w

		; Ch.1 接続 (C0h): FB = 4, CON = 0 (FM 接続)
		ld		a, 0c0h
		ld		e, 08h
		call	opl2w

		; Ch.1 F ナンバー (A0h/B0h): F# = 580, BLOCK = 4 → A4
		ld		a, 0a0h
		ld		e, 44h			; F# 下位 (580 = 244h)
		call	opl2w
		ld		a, 0b0h
		ld		e, 32h			; KON = 1, BLOCK = 4, F# 上位 = 2
		call	opl2w

		call	wait1s
		; キーオフ (KON = 0)
		ld		a, 0b0h
		ld		e, 12h
		call	opl2w

loop:
		jr		loop
