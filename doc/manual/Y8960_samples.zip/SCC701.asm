;-----------------------------------------------------------------------
;	SCC701.asm - SCC の発音 (Y8960)
;	BANK#63 を出現させ、Ch.A にサイン波を書き込んで A4 を鳴らす
;	サンプル。4000h 配置の ROM 形式。zma でアセンブルする。
;-----------------------------------------------------------------------
		org		4000h
		db		"AB"
		dw		start

start:
		; BANK2 (8000h〜9FFFh) に BANK#63 (SCC レジスタバンク) を出現させる
		; RAM モード = 0 では 9000h への書き込みが BANK2 のバンク切替になる
		ld		a, 3fh
		ld		[9000h], a

		; Ch.A 波形メモリ (9800h〜981Fh) にサイン波を書き込む
		ld		hl, sine_wave
		ld		de, 9800h
		ld		bc, 32
		ldir

		; Ch.A 周波数 (9880h/9881h): 周期値 = 253 → A4 (約 440Hz)
		ld		a, 0fdh
		ld		[9880h], a
		ld		a, 00h
		ld		[9881h], a

		; Ch.A 音量 (988Ah) = 15
		ld		a, 0fh
		ld		[988ah], a

		; 出力スイッチ (988Fh): Ch.A をオン
		ld		a, 01h
		ld		[988fh], a

loop:
		jr		loop

;	サイン波 (32 サンプル、8 ビット符号付き)
sine_wave:
		db		000h, 019h, 031h, 047h, 05ah, 06ah, 075h, 07dh
		db		07fh, 07dh, 075h, 06ah, 05ah, 047h, 031h, 019h
		db		000h, 0e7h, 0cfh, 0b9h, 0a6h, 096h, 08bh, 083h
		db		081h, 083h, 08bh, 096h, 0a6h, 0b9h, 0cfh, 0e7h
