;-----------------------------------------------------------------------
;	OPM801.asm - OPM の FM 発音 (Y8960)
;	Ch.1 (チャンネル 0) に ALG0 の音色を設定し、A4 を鳴らす
;	サンプル。4000h 配置の ROM 形式。zma でアセンブルする。
;-----------------------------------------------------------------------
		org		4000h
		db		"AB"
		dw		start

;	OPM レジスタ書き込み (A = レジスタ番号, E = データ)
opmw:
		out		[07eh], a
		ld		a, e
		out		[07fh], a
		ret

;	約 1 秒待つ
wait1s:
		ld		bc, 0
w1:		dec		bc
		ld		a, b
		or		c
		jr		nz, w1
		ret

start:
		; Enabler2 (MMIO 7FFFh) の OPM ビットを 1 にして OPM を有効化
		ld		a, 04h
		ld		[7fffh], a

		; Ch.1 チャンネル制御 (20h): RL = 両方, FB = 4, CON = 0 (ALG0)
		ld		a, 20h
		ld		e, 0e0h
		call	opmw
		; Ch.1 KC (28h) = 4Ah (A4), KF (30h) = 0
		ld		a, 28h
		ld		e, 4ah
		call	opmw
		ld		a, 30h
		ld		e, 00h
		call	opmw

		;--- M1 (オフセット +0) ---
		ld		a, 40h			; DT1 = 0, MUL = 1
		ld		e, 01h
		call	opmw
		ld		a, 60h			; TL = 24
		ld		e, 18h
		call	opmw
		ld		a, 80h			; KS = 0, AR = 28
		ld		e, 1ch
		call	opmw
		ld		a, 0a0h			; D1R = 10
		ld		e, 0ah
		call	opmw
		ld		a, 0c0h			; DT2 = 0, D2R = 4
		ld		e, 04h
		call	opmw
		ld		a, 0e0h			; D1L = 6, RR = 6
		ld		e, 66h
		call	opmw

		;--- M2 (オフセット +8) ---
		ld		a, 48h
		ld		e, 01h
		call	opmw
		ld		a, 68h
		ld		e, 20h
		call	opmw
		ld		a, 88h
		ld		e, 1ch
		call	opmw
		ld		a, 0a8h
		ld		e, 0ch
		call	opmw
		ld		a, 0c8h
		ld		e, 04h
		call	opmw
		ld		a, 0e8h
		ld		e, 56h
		call	opmw

		;--- C1 (オフセット +16) ---
		ld		a, 50h
		ld		e, 01h
		call	opmw
		ld		a, 70h
		ld		e, 1ah
		call	opmw
		ld		a, 90h
		ld		e, 1ch
		call	opmw
		ld		a, 0b0h
		ld		e, 0ah
		call	opmw
		ld		a, 0d0h
		ld		e, 04h
		call	opmw
		ld		a, 0f0h
		ld		e, 66h
		call	opmw

		;--- C2 (オフセット +24) ---
		ld		a, 58h
		ld		e, 01h
		call	opmw
		ld		a, 78h
		ld		e, 00h
		call	opmw
		ld		a, 98h
		ld		e, 1fh
		call	opmw
		ld		a, 0b8h
		ld		e, 08h
		call	opmw
		ld		a, 0d8h
		ld		e, 05h
		call	opmw
		ld		a, 0f8h
		ld		e, 47h
		call	opmw

		; キーオン (08h): 全オペレータ, チャンネル 0
		ld		a, 08h
		ld		e, 78h
		call	opmw

		call	wait1s
		; キーオフ (08h に 00h)
		ld		a, 08h
		ld		e, 00h
		call	opmw

loop:
		jr		loop
