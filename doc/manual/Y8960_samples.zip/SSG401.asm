;-----------------------------------------------------------------------
;	SSG401.asm - SSG のトーンとエンベロープ (Y8960)
;	SSG1 のチャンネル A で A4 (440Hz) を鳴らし、約 1 秒後に
;	エンベロープ (三角波、周期 約 1 秒) へ切り替えるサンプル。
;	4000h 配置の ROM 形式。zma でアセンブルする。
;-----------------------------------------------------------------------
		org		4000h
		db		"AB"
		dw		start

;	SSG1 レジスタ書き込み (A = レジスタ番号, E = データ)
ssg1w:
		out		[0a0h], a
		ld		a, e
		out		[0a1h], a
		ret

start:
		; Enabler2 (MMIO 7FFFh) の SSG ビットを 1 にして SSG を有効化
		ld		a, 02h
		ld		[7fffh], a

		; Ch.A トーン分周比 = 254 (A4 = 約 440Hz)
		ld		a, 00h
		ld		e, 0feh
		call	ssg1w
		ld		a, 01h
		ld		e, 00h
		call	ssg1w

		; ミキサー (07h): トーン A のみ許可 (負論理なので 3Eh)
		ld		a, 07h
		ld		e, 3eh
		call	ssg1w

		; Ch.A 音量 (08h) = 15
		ld		a, 08h
		ld		e, 0fh
		call	ssg1w

		; 約 1 秒待つ
		ld		bc, 0
wait_loop:
		dec		bc
		ld		a, b
		or		c
		jr		nz, wait_loop

		; エンベロープ周期 (0Bh/0Ch) = 6991 (周期 約 1 秒)
		ld		a, 0bh
		ld		e, 4fh
		call	ssg1w
		ld		a, 0ch
		ld		e, 1bh
		call	ssg1w

		; エンベロープ波形 (0Dh) = 0Ah (CONT=1, ATT=0, ALT=1, HOLD=0: 三角波)
		; 書き込んだ時点でエンベロープが再始動する
		ld		a, 0dh
		ld		e, 0ah
		call	ssg1w

		; Ch.A 音量 (08h) の M ビットを 1 にしてエンベロープへ切り替え
		ld		a, 08h
		ld		e, 10h
		call	ssg1w

loop:
		jr		loop
