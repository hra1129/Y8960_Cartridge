;-----------------------------------------------------------------------
;	OPLL501.asm - OPLL の発音とユーザー音色 (Y8960)
;	Ch.1 でプリセット音色の A4 を鳴らし、次にユーザー音色へ
;	切り替えて同じ音を鳴らすサンプル。4000h 配置の ROM 形式。
;-----------------------------------------------------------------------
		org		4000h
		db		"AB"
		dw		start

;	OPLL レジスタ書き込み (A = レジスタ番号, E = データ)
opllw:
		out		[07ch], a
		ld		a, e
		out		[07dh], a
		ret

;	約 1 秒待つ
wait1s:
		ld		bc, 0
w1:		dec		bc
		ld		a, b
		or		c
		jr		nz, w1
		ret

start:
		; Enabler1 (MMIO 7FF6h) の OPLL ビットを 1 にして OPLL を有効化
		ld		a, 01h
		ld		[7ff6h], a

		; Ch.1 音色・音量 (30h): INST = 1 (バイオリン), VOL = 0 (最大)
		ld		a, 30h
		ld		e, 10h
		call	opllw
		; Ch.1 F ナンバー下位 (10h) = 22h (F# = 290, BLOCK = 4 で A4)
		ld		a, 10h
		ld		e, 22h
		call	opllw
		; Ch.1 制御 (20h): KEY = 1, BLOCK = 4, F# の最上位ビット = 1
		ld		a, 20h
		ld		e, 19h
		call	opllw

		call	wait1s
		; キーオフ (KEY = 0)
		ld		a, 20h
		ld		e, 09h
		call	opllw

		; ユーザー音色 (00h〜07h) を設定する
		ld		a, 00h			; モジュレータ: EGT=1, MULTI=1
		ld		e, 21h
		call	opllw
		ld		a, 01h			; キャリア: EGT=1, MULTI=1
		ld		e, 21h
		call	opllw
		ld		a, 02h			; モジュレータ TL = 24
		ld		e, 18h
		call	opllw
		ld		a, 03h			; フィードバック = 5
		ld		e, 05h
		call	opllw
		ld		a, 04h			; モジュレータ AR=15, DR=8
		ld		e, 0f8h
		call	opllw
		ld		a, 05h			; キャリア AR=15, DR=6
		ld		e, 0f6h
		call	opllw
		ld		a, 06h			; モジュレータ SL=4, RR=6
		ld		e, 46h
		call	opllw
		ld		a, 07h			; キャリア SL=3, RR=6
		ld		e, 36h
		call	opllw

		; Ch.1 をユーザー音色 (INST = 0), VOL = 2 に切り替えて再び発音
		ld		a, 30h
		ld		e, 02h
		call	opllw
		ld		a, 20h
		ld		e, 19h
		call	opllw

		call	wait1s
		ld		a, 20h
		ld		e, 09h
		call	opllw

loop:
		jr		loop
